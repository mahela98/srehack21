
import java.util.Properties;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.FlagTerm;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Test {


	public static void check(String host, String storeType, String user, String password) {
		try {
			
			MongoClient client = MongoClients.create("mongodb+srv://hackathon:hackathon@cluster0.wsucm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
			MongoDatabase db = client.getDatabase("emailDB");
		 	MongoCollection<Document> collection = db.getCollection("emailCollection");
		 	Document doc = new Document();
			
			
			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.imap.starttls.enable", "true");
			properties.put("mail.imap.ssl.trust", host);

			Session emailSession = Session.getDefaultInstance(properties);

			// create the imap store object and connect to the imap server
			Store store = emailSession.getStore("imaps");

			store.connect(host, user, password);

			// create the inbox object and open it
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);

			// retrieve the messages from the folder in an array and print it
			Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));

			for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
				message.setFlag(Flag.SEEN, true);
				
				
				doc.append("subject", message.getSubject());
				doc.append("sender", message.getFrom()[0]);
				doc.append("body", message.getContent().toString());
				doc.append("date", message.getReceivedDate());
				
				collection.insertOne(doc);
			}

			inbox.close(false);
			store.close();

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		String host = "imap.gmail.com";
		String mailStoreType = "imap";
		String username = "hackathonsamplehorizon@gmail.com";
		String password = "Hack@horizon";

		check(host, mailStoreType, username, password);

	}
	
}
